package den.secretary;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import android.provider.CalendarContract.Instances;
import android.provider.CalendarContract.Reminders;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

/**
 * Two-way bridge with the phone calendar:
 *  1. Secretary events and reminders → local calendar «Секретарь» on the phone, with alarms
 *     (so the phone itself notifies, even when the app is closed).
 *  2. Den's other phone calendars (next 60 days) → server, read-only, so the secretary knows the whole schedule.
 */
public class CalendarSync {
    static final String ACC = "Секретарь";
    static final String TZ = "Europe/Madrid";

    static Uri asSync(Uri uri) {
        return uri.buildUpon()
                .appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER, "true")
                .appendQueryParameter(Calendars.ACCOUNT_NAME, ACC)
                .appendQueryParameter(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL).build();
    }

    static boolean allowed(Context ctx) {
        return ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && ctx.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    static String http(String method, String url, String token, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setRequestProperty("X-Token", token);
        c.setRequestProperty("Content-Type", "application/json");
        if (body != null) {
            c.setDoOutput(true);
            try (OutputStream o = c.getOutputStream()) {
                o.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = c.getResponseCode();
        InputStream in = code < 300 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while (in != null && (n = in.read(b)) > 0) buf.write(b, 0, n);
        if (code >= 300) throw new Exception("server " + code);
        return buf.toString("UTF-8");
    }

    static long ensureCalendar(ContentResolver cr) {
        try (Cursor c = cr.query(Calendars.CONTENT_URI, new String[]{Calendars._ID},
                Calendars.ACCOUNT_NAME + "=? AND " + Calendars.ACCOUNT_TYPE + "=?",
                new String[]{ACC, CalendarContract.ACCOUNT_TYPE_LOCAL}, null)) {
            if (c != null && c.moveToFirst()) return c.getLong(0);
        }
        ContentValues v = new ContentValues();
        v.put(Calendars.ACCOUNT_NAME, ACC);
        v.put(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL);
        v.put(Calendars.NAME, ACC);
        v.put(Calendars.CALENDAR_DISPLAY_NAME, ACC);
        v.put(Calendars.CALENDAR_COLOR, 0xFF2B5B79);
        v.put(Calendars.CALENDAR_ACCESS_LEVEL, Calendars.CAL_ACCESS_OWNER);
        v.put(Calendars.OWNER_ACCOUNT, ACC);
        v.put(Calendars.VISIBLE, 1);
        v.put(Calendars.SYNC_EVENTS, 1);
        v.put(Calendars.CALENDAR_TIME_ZONE, TZ);
        Uri u = cr.insert(asSync(Calendars.CONTENT_URI), v);
        return u == null ? -1 : ContentUris.parseId(u);
    }

    /** All-day events must start at UTC midnight of the local date. */
    static long utcMidnight(long localMs, int addDays) {
        Calendar l = Calendar.getInstance(TimeZone.getTimeZone(TZ));
        l.setTimeInMillis(localMs);
        Calendar u = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        u.clear();
        u.set(l.get(Calendar.YEAR), l.get(Calendar.MONTH), l.get(Calendar.DAY_OF_MONTH));
        u.add(Calendar.DAY_OF_MONTH, addDays);
        return u.getTimeInMillis();
    }

    /** Last known position → server, for «выезжай через N минут». Silent if not allowed. */
    static void sendLocation(Context ctx, String host, String token) {
        try {
            if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            android.location.LocationManager lm = (android.location.LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            android.location.Location best = null;
            for (String prov : lm.getProviders(true)) {
                android.location.Location l = lm.getLastKnownLocation(prov);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best == null || System.currentTimeMillis() - best.getTime() > 3 * 3600 * 1000L) return;
            http("POST", "https://" + host + "/api/location", token,
                    new JSONObject().put("lat", best.getLatitude()).put("lon", best.getLongitude()).toString());
        } catch (Exception ignored) {
        }
    }

    public static synchronized String run(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("secretary", Context.MODE_PRIVATE);
        String host = p.getString("server_host", ""), token = p.getString("token", "");
        if (host.isEmpty() || token.isEmpty()) return "Сначала войди в приложение.";
        sendLocation(ctx, host, token);
        if (!allowed(ctx)) return "Нет доступа к календарю телефона.";
        try {
            ContentResolver cr = ctx.getContentResolver();
            long calId = ensureCalendar(cr);
            if (calId < 0) return "Не удалось создать календарь «Секретарь».";

            // 1. secretary → phone
            JSONArray evs = new JSONObject(http("GET", "https://" + host + "/api/sync/export?days=60", token, null))
                    .getJSONArray("events");
            Map<String, Long> existing = new HashMap<>();
            try (Cursor c = cr.query(asSync(Events.CONTENT_URI), new String[]{Events._ID, Events._SYNC_ID},
                    Events.CALENDAR_ID + "=?", new String[]{String.valueOf(calId)}, null)) {
                while (c != null && c.moveToNext()) existing.put(c.getString(1), c.getLong(0));
            }
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < evs.length(); i++) {
                JSONObject e = evs.getJSONObject(i);
                String sid = e.getString("id");
                seen.add(sid);
                boolean allDay = e.optBoolean("all_day");
                long st = e.getLong("start"), en = Math.max(e.getLong("end"), st);
                ContentValues v = new ContentValues();
                v.put(Events.CALENDAR_ID, calId);
                v.put(Events.TITLE, e.optString("title"));
                v.put(Events.EVENT_LOCATION, e.optString("location"));
                v.put(Events.DESCRIPTION, e.optString("notes"));
                v.put(Events.ALL_DAY, allDay ? 1 : 0);
                v.put(Events.DTSTART, allDay ? utcMidnight(st, 0) : st);
                v.put(Events.DTEND, allDay ? utcMidnight(st, 1) : (en > st ? en : st + 15 * 60000));
                v.put(Events.EVENT_TIMEZONE, allDay ? "UTC" : TZ);
                JSONArray alarms = e.optJSONArray("alarms");
                v.put(Events.HAS_ALARM, alarms != null && alarms.length() > 0 ? 1 : 0);
                v.put(Events._SYNC_ID, sid);
                long eventId;
                if (existing.containsKey(sid)) {
                    eventId = existing.get(sid);
                    cr.update(asSync(ContentUris.withAppendedId(Events.CONTENT_URI, eventId)), v, null, null);
                } else {
                    Uri u = cr.insert(asSync(Events.CONTENT_URI), v);
                    if (u == null) continue;
                    eventId = ContentUris.parseId(u);
                }
                cr.delete(asSync(Reminders.CONTENT_URI), Reminders.EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
                for (int k = 0; alarms != null && k < alarms.length(); k++) {
                    ContentValues r = new ContentValues();
                    r.put(Reminders.EVENT_ID, eventId);
                    r.put(Reminders.MINUTES, alarms.getInt(k));
                    r.put(Reminders.METHOD, Reminders.METHOD_ALERT);
                    cr.insert(asSync(Reminders.CONTENT_URI), r);
                }
            }
            int removed = 0;
            for (Map.Entry<String, Long> x : existing.entrySet()) {
                if (!seen.contains(x.getKey())) {
                    cr.delete(asSync(ContentUris.withAppendedId(Events.CONTENT_URI, x.getValue())), null, null);
                    removed++;
                }
            }

            // 2. phone → secretary (other calendars only, read-only)
            long now = System.currentTimeMillis();
            Uri.Builder b = Instances.CONTENT_URI.buildUpon();
            ContentUris.appendId(b, now - 86400000L);
            ContentUris.appendId(b, now + 60L * 86400000L);
            JSONArray mine = new JSONArray();
            try (Cursor c = cr.query(b.build(), new String[]{Instances.EVENT_ID, Instances.BEGIN, Instances.END,
                            Instances.TITLE, Instances.ALL_DAY, Instances.EVENT_LOCATION, Instances.CALENDAR_ID,
                            Instances.CALENDAR_DISPLAY_NAME},
                    Instances.CALENDAR_ID + "!=?", new String[]{String.valueOf(calId)}, Instances.BEGIN + " ASC")) {
                while (c != null && c.moveToNext() && mine.length() < 3000) {
                    JSONObject o = new JSONObject();
                    boolean allDay = c.getInt(4) == 1;
                    long beg = c.getLong(1), end = c.getLong(2);
                    if (allDay) {  // all-day instances are stored in UTC — shift to local midnight
                        int off = TimeZone.getTimeZone(TZ).getOffset(beg);
                        beg -= off;
                        end -= off;
                    }
                    o.put("id", c.getLong(0) + ":" + c.getLong(1));
                    o.put("start", beg);
                    o.put("end", end);
                    o.put("title", c.getString(3));
                    o.put("all_day", allDay);
                    o.put("location", c.getString(5));
                    o.put("calendar", c.getString(7));
                    mine.put(o);
                }
            }
            http("POST", "https://" + host + "/api/sync/phone", token, new JSONObject().put("events", mine).toString());
            p.edit().putLong("cal_sync_at", now).apply();
            return "Синхронизировано: " + evs.length() + " в календарь телефона, " + mine.length()
                    + " из телефона секретарю" + (removed > 0 ? ", удалено " + removed : "") + ".";
        } catch (Exception ex) {
            return "Ошибка синхронизации: " + ex.getMessage();
        }
    }
}
