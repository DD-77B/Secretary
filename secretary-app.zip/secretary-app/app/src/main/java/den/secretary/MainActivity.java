package den.secretary;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String KEY = "server_host";
    private SharedPreferences prefs;
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private PermissionRequest pendingMic;
    private ValueCallback<Uri[]> fileCb;
    private static final int REQ_FILE = 21;
    private static final int REQ_MIC = 11, REQ_CONTACTS = 12, REQ_CAL = 13, REQ_LOC = 14;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("secretary", MODE_PRIVATE);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("ru", "RU"));
                ttsReady = true;
            }
        });
        String host = prefs.getString(KEY, "");
        if (host.isEmpty()) showSetup();
        else showPanel(host);
        takeShare(getIntent());
    }

    /* ---------- «Поделиться» → notes archive ---------- */
    private String pendingShare = null;
    private boolean pageReady = false;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        takeShare(intent);
    }

    private void takeShare(Intent in) {
        if (in == null) return;
        String act = in.getAction();
        if (!Intent.ACTION_SEND.equals(act) && !Intent.ACTION_SEND_MULTIPLE.equals(act)) return;
        new Thread(() -> {
            try {
                JSONArray items = new JSONArray();
                String subject = in.getStringExtra(Intent.EXTRA_SUBJECT);
                String text = in.getStringExtra(Intent.EXTRA_TEXT);
                java.util.ArrayList<CharSequence> texts = in.getCharSequenceArrayListExtra(Intent.EXTRA_TEXT);
                if (texts != null) for (CharSequence t : texts) items.put(new JSONObject().put("text", t.toString()));
                else if (text != null && !text.trim().isEmpty())
                    items.put(new JSONObject().put("text", text).put("subject", subject == null ? "" : subject));
                java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                if (Intent.ACTION_SEND_MULTIPLE.equals(act)) {
                    java.util.ArrayList<Uri> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                    if (l != null) uris.addAll(l);
                } else {
                    Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
                    if (u != null) uris.add(u);
                }
                for (Uri u : uris) {
                    String type = getContentResolver().getType(u);
                    try (java.io.InputStream is = getContentResolver().openInputStream(u)) {
                        if (is == null) continue;
                        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = is.read(buf)) > 0 && bo.size() < 8_000_000) bo.write(buf, 0, n);
                        if (type != null && type.startsWith("text/")) {
                            items.put(new JSONObject().put("text", bo.toString("UTF-8")));
                        } else {
                            String b64 = android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP);
                            items.put(new JSONObject().put("image", "data:" + (type == null ? "image/jpeg" : type) + ";base64," + b64));
                        }
                    } catch (Exception ignored) {
                    }
                }
                if (items.length() == 0) return;
                String call = "window.onShared && window.onShared(" + JSONObject.quote(items.toString()) + ")";
                runOnUiThread(() -> {
                    if (pageReady) js(call);
                    else pendingShare = call;
                });
            } catch (Exception ignored) {
            }
        }).start();
        in.setAction(Intent.ACTION_MAIN);  // don't import the same share twice after rotation
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView label(String s, int sp, int colorRes, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(getColor(colorRes));
        t.setLineSpacing(0, 1.2f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable rounded(int fillRes, int strokeRes) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(getColor(fillRes));
        g.setCornerRadius(dp(12));
        if (strokeRes != 0) g.setStroke(dp(1), getColor(strokeRes));
        return g;
    }

    /** "65.21.3.4", "65-21-3-4.sslip.io" or a full https link → host name. */
    static String toHost(String raw) {
        String s = raw.trim().toLowerCase();
        if (s.isEmpty()) return null;
        if (s.contains("://")) {
            String h = Uri.parse(s).getHost();
            s = h == null ? "" : h;
        }
        int slash = s.indexOf('/');
        if (slash >= 0) s = s.substring(0, slash);
        s = s.replace(" ", "").replace(',', '.').replaceAll("^\\.+|\\.+$", "");
        if (s.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return s.replace('.', '-') + ".sslip.io";
        if (s.matches("[a-z0-9.-]+\\.[a-z]{2,}")) return s;
        return null;
    }

    private void showSetup() {
        destroyWeb();
        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.setBackgroundColor(getColor(R.color.bg));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(56), dp(24), dp(24));
        scroll.addView(box);

        box.addView(label("Секретарь", 30, R.color.ink, true));
        TextView sub = label("Введи АДРЕС, который установщик показал в конце на сервере, например 65.21.123.45. "
                + "Код введёшь на следующем шаге.", 16, R.color.muted, false);
        sub.setPadding(0, dp(8), 0, dp(24));
        box.addView(sub);

        EditText input = new EditText(this);
        input.setHint("65.21.123.45");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        input.setTextColor(getColor(R.color.ink));
        input.setHintTextColor(getColor(R.color.muted));
        input.setBackground(rounded(R.color.field, R.color.muted));
        input.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.addView(input);

        TextView err = label("", 15, R.color.red, false);
        err.setPadding(0, dp(10), 0, 0);
        err.setVisibility(View.GONE);
        box.addView(err);

        Button go = new Button(this);
        go.setText("Подключить");
        go.setAllCaps(false);
        go.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        go.setTextColor(getColor(R.color.bg));
        go.setBackground(rounded(R.color.blue, 0));
        go.setStateListAnimator(null);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(20);
        box.addView(go, lp);

        go.setOnClickListener(v -> {
            String host = toHost(input.getText().toString());
            if (host == null) {
                err.setText("Это не похоже на адрес сервера. Введи четыре числа через точку, как в конце установки.");
                err.setVisibility(View.VISIBLE);
                return;
            }
            prefs.edit().putString(KEY, host).apply();
            showPanel(host);
        });
        setContentView(scroll);
    }

    private void destroyWeb() {
        if (web != null) {
            web.destroy();
            web = null;
        }
    }

    private void showPanel(String host) {
        destroyWeb();
        web = new WebView(this);
        web.setFitsSystemWindows(true);
        web.setBackgroundColor(getColor(R.color.bg));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient() {
            /** <input type="file"> in the panel (screenshots for the address book). */
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        pendingMic = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "SecretaryApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                pageReady = true;
                if (pendingShare != null) {
                    String c = pendingShare;
                    pendingShare = null;
                    v.postDelayed(() -> js(c), 1500);  // let the panel log in first
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (host.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showOffline(String.valueOf(e.getDescription()));
            }

            @Override
            public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse resp) {
                if (r.isForMainFrame() && resp.getStatusCode() >= 500)
                    showOffline("Сервер ответил ошибкой " + resp.getStatusCode() + ".");
            }
        });
        setContentView(web);
        web.loadUrl("https://" + host + "/panel");
    }

    private void showOffline(String reason) {
        if (web == null) return;
        String safe = reason == null ? "" : reason.replace("&", "&amp;").replace("<", "&lt;");
        String html = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
                + "<style>:root{--bg:#E8ECEF;--ink:#15212B;--muted:#5D6C77;--blue:#2B5B79;--on:#fff;--line:#CAD2D8}"
                + "@media(prefers-color-scheme:dark){:root{--bg:#0D151B;--ink:#E2E9EE;--muted:#8C9AA5;--blue:#7FB0CF;--on:#0D151B;--line:#253441}}"
                + "body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.45 system-ui,sans-serif;padding:72px 24px}"
                + "h1{font-size:26px;margin:0 0 8px}p{color:var(--muted);margin:0 0 28px}"
                + "button{display:block;width:100%;font:inherit;font-weight:600;padding:14px;border-radius:12px;margin-bottom:12px}"
                + ".a{background:var(--blue);color:var(--on);border:0}.b{background:none;color:var(--ink);border:1px solid var(--line)}</style></head>"
                + "<body><h1>Сервер не отвечает</h1><p>Проверь интернет. Если он есть — сервер выключен, ещё получает сертификат "
                + "(первые минуты после установки) или адрес введён с ошибкой. " + safe + "</p>"
                + "<button class=a onclick='SecretaryApp.retry()'>Повторить</button>"
                + "<button class=b onclick='SecretaryApp.reset()'>Ввести другой адрес</button></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCb = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (code == REQ_MIC && pendingMic != null) {
            if (ok) pendingMic.grant(pendingMic.getResources());
            else pendingMic.deny();
            pendingMic = null;
        } else if (code == REQ_LOC) {
            js("window.onCalSync && window.onCalSync(" + JSONObject.quote(ok ? "Геолокация разрешена — секретарь будет считать дорогу от того места, где ты." : "Геолокация не разрешена — дорога будет считаться от домашнего адреса.") + ")");
            if (ok) syncNow();
        } else if (code == REQ_CAL) {
            if (CalendarSync.allowed(this)) syncNow();
            else js("window.onCalSync && window.onCalSync('Нет доступа к календарю телефона — разреши его в настройках.')");
        } else if (code == REQ_CONTACTS) {
            if (ok) sendContacts();
            else js("window.onContacts && window.onContacts(null)");
        }
    }

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    /** Reads the phone book and hands it to the panel as [{name, phones:[...]}]. */
    private void sendContacts() {
        new Thread(() -> {
            Map<String, JSONArray> map = new LinkedHashMap<>();
            String[] cols = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER};
            try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    cols, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        String name = c.getString(0), num = c.getString(1);
                        if (name == null || num == null) continue;
                        JSONArray arr = map.get(name);
                        if (arr == null) { arr = new JSONArray(); map.put(name, arr); }
                        if (arr.length() < 5) arr.put(num);
                    }
                }
            } catch (Exception ignored) {
            }
            JSONArray out = new JSONArray();
            try {
                for (Map.Entry<String, JSONArray> e : map.entrySet()) {
                    JSONObject o = new JSONObject();
                    o.put("name", e.getKey());
                    o.put("phones", e.getValue());
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            String payload = out.toString();
            runOnUiThread(() -> js("window.onContacts && window.onContacts(" + payload + ")"));
        }).start();
    }

    private void syncNow() {
        SyncJob.schedule(this);
        new Thread(() -> {
            String res = CalendarSync.run(getApplicationContext());
            runOnUiThread(() -> js("window.onCalSync && window.onCalSync(" + JSONObject.quote(res) + ")"));
        }).start();
    }

    private class Bridge {
        @JavascriptInterface
        public void setAuth(String token) {
            if (token != null && !token.isEmpty()) prefs.edit().putString("token", token).apply();
        }

        /** Haptic feedback: pattern = JSON array of on/off durations in ms, amplitude 1..255. */
        @JavascriptInterface
        public void vibrate(String patternJson, int amplitude) {
            try {
                org.json.JSONArray a = new org.json.JSONArray(patternJson);
                long[] timings = new long[a.length() + 1];
                int[] amps = new int[a.length() + 1];
                timings[0] = 0;
                amps[0] = 0;
                int amp = Math.max(1, Math.min(255, amplitude));
                for (int i = 0; i < a.length(); i++) {
                    timings[i + 1] = Math.max(1, a.getLong(i));
                    amps[i + 1] = (i % 2 == 0) ? amp : 0;  // even = vibrate, odd = pause
                }
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                if (v.hasAmplitudeControl()) {
                    v.vibrate(android.os.VibrationEffect.createWaveform(timings, amps, -1));
                } else {
                    v.vibrate(android.os.VibrationEffect.createWaveform(timings, -1));
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void stopSpeak() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }

        @JavascriptInterface
        public void requestLocation() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC));
        }

        @JavascriptInterface
        public void syncCalendar(boolean ask) {
            runOnUiThread(() -> {
                if (CalendarSync.allowed(MainActivity.this)) syncNow();
                else if (!ask) { SyncJob.schedule(MainActivity.this); new Thread(() -> CalendarSync.run(getApplicationContext())).start(); }
                else if (ask) requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,
                        Manifest.permission.WRITE_CALENDAR}, REQ_CAL);
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "secretary");
            });
        }

        @JavascriptInterface
        public void loadContacts(boolean ask) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                    sendContacts();
                } else if (ask) {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
                }
            });
        }

        @JavascriptInterface
        public void retry() {
            runOnUiThread(() -> {
                String h = prefs.getString(KEY, "");
                if (h.isEmpty()) showSetup();
                else showPanel(h);
            });
        }

        @JavascriptInterface
        public void reset() {
            runOnUiThread(() -> {
                prefs.edit().remove(KEY).apply();
                showSetup();
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.onPause();
            web.pauseTimers();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        destroyWeb();
        super.onDestroy();
    }
}
