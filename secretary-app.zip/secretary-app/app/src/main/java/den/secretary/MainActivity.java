package den.secretary;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import android.webkit.PermissionRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String KEY = "server_host";
    private SharedPreferences prefs;
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private PermissionRequest pendingMic;
    private static final int REQ_MIC = 11, REQ_CONTACTS = 12;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("secretary", MODE_PRIVATE);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("ru", "RU"));
                ttsReady = true;
            }
        });
        String host = prefs.getString(KEY, "");
        if (host.isEmpty()) showSetup();
        else showPanel(host);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView label(String s, int sp, int colorRes, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(getColor(colorRes));
        t.setLineSpacing(0, 1.2f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable rounded(int fillRes, int strokeRes) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(getColor(fillRes));
        g.setCornerRadius(dp(12));
        if (strokeRes != 0) g.setStroke(dp(1), getColor(strokeRes));
        return g;
    }

    /** "65.21.3.4", "65-21-3-4.sslip.io" or a full https link → host name. */
    static String toHost(String raw) {
        String s = raw.trim().toLowerCase();
        if (s.isEmpty()) return null;
        if (s.contains("://")) {
            String h = Uri.parse(s).getHost();
            s = h == null ? "" : h;
        }
        int slash = s.indexOf('/');
        if (slash >= 0) s = s.substring(0, slash);
        s = s.replace(" ", "").replace(',', '.').replaceAll("^\\.+|\\.+$", "");
        if (s.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return s.replace('.', '-') + ".sslip.io";
        if (s.matches("[a-z0-9.-]+\\.[a-z]{2,}")) return s;
        return null;
    }

    private void showSetup() {
        destroyWeb();
        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.setBackgroundColor(getColor(R.color.bg));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(56), dp(24), dp(24));
        scroll.addView(box);

        box.addView(label("Секретарь", 30, R.color.ink, true));
        TextView sub = label("Введи АДРЕС, который установщик показал в конце на сервере, например 65.21.123.45. "
                + "Код введёшь на следующем шаге.", 16, R.color.muted, false);
        sub.setPadding(0, dp(8), 0, dp(24));
        box.addView(sub);

        EditText input = new EditText(this);
        input.setHint("65.21.123.45");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        input.setTextColor(getColor(R.color.ink));
        input.setHintTextColor(getColor(R.color.muted));
        input.setBackground(rounded(R.color.field, R.color.muted));
        input.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.addView(input);

        TextView err = label("", 15, R.color.red, false);
        err.setPadding(0, dp(10), 0, 0);
        err.setVisibility(View.GONE);
        box.addView(err);

        Button go = new Button(this);
        go.setText("Подключить");
        go.setAllCaps(false);
        go.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        go.setTextColor(getColor(R.color.bg));
        go.setBackground(rounded(R.color.blue, 0));
        go.setStateListAnimator(null);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(20);
        box.addView(go, lp);

        go.setOnClickListener(v -> {
            String host = toHost(input.getText().toString());
            if (host == null) {
                err.setText("Это не похоже на адрес сервера. Введи четыре числа через точку, как в конце установки.");
                err.setVisibility(View.VISIBLE);
                return;
            }
            prefs.edit().putString(KEY, host).apply();
            showPanel(host);
        });
        setContentView(scroll);
    }

    private void destroyWeb() {
        if (web != null) {
            web.destroy();
            web = null;
        }
    }

    private void showPanel(String host) {
        destroyWeb();
        web = new WebView(this);
        web.setFitsSystemWindows(true);
        web.setBackgroundColor(getColor(R.color.bg));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        pendingMic = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "SecretaryApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (host.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showOffline(String.valueOf(e.getDescription()));
            }

            @Override
            public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse resp) {
                if (r.isForMainFrame() && resp.getStatusCode() >= 500)
                    showOffline("Сервер ответил ошибкой " + resp.getStatusCode() + ".");
            }
        });
        setContentView(web);
        web.loadUrl("https://" + host + "/panel");
    }

    private void showOffline(String reason) {
        if (web == null) return;
        String safe = reason == null ? "" : reason.replace("&", "&amp;").replace("<", "&lt;");
        String html = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
                + "<style>:root{--bg:#E8ECEF;--ink:#15212B;--muted:#5D6C77;--blue:#2B5B79;--on:#fff;--line:#CAD2D8}"
                + "@media(prefers-color-scheme:dark){:root{--bg:#0D151B;--ink:#E2E9EE;--muted:#8C9AA5;--blue:#7FB0CF;--on:#0D151B;--line:#253441}}"
                + "body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.45 system-ui,sans-serif;padding:72px 24px}"
                + "h1{font-size:26px;margin:0 0 8px}p{color:var(--muted);margin:0 0 28px}"
                + "button{display:block;width:100%;font:inherit;font-weight:600;padding:14px;border-radius:12px;margin-bottom:12px}"
                + ".a{background:var(--blue);color:var(--on);border:0}.b{background:none;color:var(--ink);border:1px solid var(--line)}</style></head>"
                + "<body><h1>Сервер не отвечает</h1><p>Проверь интернет. Если он есть — сервер выключен, ещё получает сертификат "
                + "(первые минуты после установки) или адрес введён с ошибкой. " + safe + "</p>"
                + "<button class=a onclick='SecretaryApp.retry()'>Повторить</button>"
                + "<button class=b onclick='SecretaryApp.reset()'>Ввести другой адрес</button></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (code == REQ_MIC && pendingMic != null) {
            if (ok) pendingMic.grant(pendingMic.getResources());
            else pendingMic.deny();
            pendingMic = null;
        } else if (code == REQ_CONTACTS) {
            if (ok) sendContacts();
            else js("window.onContacts && window.onContacts(null)");
        }
    }

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    /** Reads the phone book and hands it to the panel as [{name, phones:[...]}]. */
    private void sendContacts() {
        new Thread(() -> {
            Map<String, JSONArray> map = new LinkedHashMap<>();
            String[] cols = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER};
            try (Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    cols, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        String name = c.getString(0), num = c.getString(1);
                        if (name == null || num == null) continue;
                        JSONArray arr = map.get(name);
                        if (arr == null) { arr = new JSONArray(); map.put(name, arr); }
                        if (arr.length() < 5) arr.put(num);
                    }
                }
            } catch (Exception ignored) {
            }
            JSONArray out = new JSONArray();
            try {
                for (Map.Entry<String, JSONArray> e : map.entrySet()) {
                    JSONObject o = new JSONObject();
                    o.put("name", e.getKey());
                    o.put("phones", e.getValue());
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            String payload = out.toString();
            runOnUiThread(() -> js("window.onContacts && window.onContacts(" + payload + ")"));
        }).start();
    }

    private class Bridge {
        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "secretary");
            });
        }

        @JavascriptInterface
        public void loadContacts(boolean ask) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                    sendContacts();
                } else if (ask) {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
                }
            });
        }

        @JavascriptInterface
        public void retry() {
            runOnUiThread(() -> {
                String h = prefs.getString(KEY, "");
                if (h.isEmpty()) showSetup();
                else showPanel(h);
            });
        }

        @JavascriptInterface
        public void reset() {
            runOnUiThread(() -> {
                prefs.edit().remove(KEY).apply();
                showSetup();
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.onPause();
            web.pauseTimers();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        destroyWeb();
        super.onDestroy();
    }
}
